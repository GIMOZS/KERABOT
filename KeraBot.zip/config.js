exports.Prefix = `.`;
exports.Color = `RANDOM`;

//Put the Token in Client secrets LOCK Button
